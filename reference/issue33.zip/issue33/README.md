# issue33

Reference implementation of *issue33.com* to run locally (for comparison or inspection) at port `3551`. 

```shell
$ cd issue33
issue33$ pnpm i

Lockfile is up to date, resolution step is skipped
Packages: +14
++++++++++++++
Progress: resolved 14, reused 14, downloaded 0, added 14, done

dependencies:
+ serve-handler 6.1.5

Done in 400ms

issue33$ pnpm run serve

> reference@0.0.0 serve /issue33
> node ./index.mjs

Running at http://localhost:3551
```
