#!/bin/bash
# find . -type f -name '*.html' -exec grep -o -P '.{0,10}="https:\/\/issue33\.com.{0,10}' {} +
# find . -type f -name '*.html' -exec sed -n 's/="https:\/\/issue33\.com/="http:\/\/localhost:3551/gp' {} +
find . -type f -name '*.html' -exec sed -i 's/="https:\/\/issue33\.com/="http:\/\/localhost:3551/g' {} +
